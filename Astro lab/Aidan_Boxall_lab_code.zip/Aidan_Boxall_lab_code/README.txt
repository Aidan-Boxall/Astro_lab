aip.py produces the data needed to produce the graphs and catalogue and saves them in a pickle file. Therefore this code has to be run first. This file requires a copy of mosaic.fits to run.

catalogue.py outputs the catalogue as a text file. 

graph.py produces the graph of log(N(m)) vs m.

hist.py produces a histogram of the background counts and calculates the mean and standard deviation.

wholehist.py produces a histogram of the count values of all of the pixels in the image.